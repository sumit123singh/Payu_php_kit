<?php

require_once dirname( __FILE__ ) . '/payu.php';

/* Payments made easy. */

pay_page( array (	'key' => 'tradus', 'txnid' => uniqid( 'animesh_' ), 'amount' => rand( 0, 100 ),
			'firstname' => 'animesh', 'email' => 'animesh.kundu@payu.in', 'phone' => '1234567890',
			'productinfo' => 'This is shit', 'surl' => 'payment_success', 'furl' => 'payment_failure'), '200' );

/* And we are done. */
			


function payment_success() {
	/* Payment success logic goes here. */
	echo "Payment Success" . "<pre>" . print_r( $_POST, true ) . "</pre>";
}

function payment_failure() {
	/* Payment failure logic goes here. */
	echo "Payment Failure" . "<pre>" . print_r( $_POST, true ) . "</pre>";
}
